<!DOCTYPE html>
<html lang=en>
<head>
  <meta charset=utf-8>
  <title>Monitordroid Form</title>
</head>
 
<body>

<h1>This would be a form where you'd enter information</h1>
</body>
</html>
